# Tiến độ 5 chủ đề (cập nhật 27/10/2026)

| Đề | Chủ đề | Dùng khi | Mức | Trạng thái | Trong zip |
|---|---|---|---|---|---|
| 1 | Khi Le Chatelier "đoán sai" (khí trơ, pha loãng, chất rắn) | Về nhà sau Buổi 2 | M3–M4 | Chưa có idea | Chưa có file |
| 2 | Nhà máy NH₃ và vòng tuần hoàn | Về nhà sau Buổi 2 | M3–M4 | Chưa có idea | Ảnh gốc tham khảo sơ đồ Haber (cắt từ ảnh chụp tes.com, độ phân giải thấp, chỉ làm mẫu để vẽ lại) |
| 3 | Hemoglobin, CO và buồng oxy cao áp | Về nhà sau Buổi 2 | M3–M4 | Chưa có idea | Chưa có file |
| 4 | Từ hồ muối Ai Cập đến hằng số Kc | 30 phút đầu Buổi 3 | M2 | Có idea + prompt Gemini + gợi ý hình; chờ output Gemini | De 4 - idea va prompt Gemini.md |
| 5 | Nhật ký lò tổng hợp methanol | 30 phút đầu Buổi 3 | M2 | Có idea + prompt Gemini + gợi ý hình; chờ output Gemini | De 5 - idea va prompt Gemini.md |

Bước tiếp theo:
- Đề 4, 5: dán prompt vào Gemini, gửi output lại để lọc còn 8 câu mỗi đề (D4), rồi check toàn diện (D5).
- Đề 1, 2, 3: viết idea + prompt Gemini.
- Ảnh còn thiếu: sơ đồ dây chuyền NH₃ (Đề 2, vẽ lại theo mẫu); Hb gắn O₂/CO và buồng oxy cao áp (Đề 3); màu đỏ máu FeSCN²⁺ (Đề 1, không bắt buộc).
